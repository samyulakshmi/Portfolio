import React from 'react'
import './experience.css'
import { FaCheck } from "react-icons/fa6";

function Experience() {
  return (
    <section id='experiences'>
      <h5>My Journey</h5>
      <h2>Services</h2>
      <div className="container experiences__container">
        <article className="experience">
           <div className="experience__head">
            <h3>Software Developer Trainee</h3>
           </div>
           <ul className="experience__list">
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
           </ul>
        </article>
        <article className="experience">
           <div className="experience__head">
            <h3>R&D Engineer</h3>
           </div>
           <ul className="experience__list">
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
            <li>
              <FaCheck className='experience__list-icon'/>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
            </li>
           </ul>
        </article>
      </div>
    </section>
  )
}

export default Experience